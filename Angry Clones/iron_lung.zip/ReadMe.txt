IRON LUNG
A TrueType Font by S. John Ross
Cumberland Games & Diversions
www.cumberlandgames.com

This font's sort of a hybrid, with elements of both a stressed font and an engraved font, with the end result standing in for crudely stamped letters from a plate of metal. It�s an all-caps* font with a full keyboard set and the usual extras I tend to toss in (a few fractions, smart-quotes, dashes and whatnot). Enjoy.

This font is copyright 2004 by S. John Ross. "Cumberland Games & Diversions" is a trademark of S. John Ross. This font is freeware for private, non-commercial use. Contact me at sjohn@cumberlandgames.com if you're interested in a licence for public or organizational use.

*The commercial version of this font includes an additional set of lowercase characters.

This ZIP archive may be freely distributed provided none of the contents are altered or removed.

Version 1.0
